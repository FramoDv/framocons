# Framocons
An open source icon-font made with simplicity, fantasy and geometry.
